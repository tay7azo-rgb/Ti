# ثِق (THIQ AI)

واجهة ويب + نواة ذكاء اصطناعي (Google Gemini).

## هيكل المستودع (الجذر)

```
requirements.txt
server.py          # FastAPI — المتغير app
static/index.html  # الواجهة (بدون تغيير تصميم)
thiq/              # نواة الذكاء الاصطناعي
Procfile
render.yaml
runtime.txt
```

## النشر على Render

1. ارفع **محتويات** هذا المجلد إلى **جذر** مستودع GitHub.
2. New → Web Service → اختر المستودع.
3. الإعدادات:
   - **Root Directory:** اتركه فارغًا
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `uvicorn server:app --host 0.0.0.0 --port $PORT`
4. Environment:
   - `GEMINI_API_KEY` = مفتاحك من [Google AI Studio](https://aistudio.google.com/apikey)

## تشغيل محلي

```bash
pip install -r requirements.txt
cp .env.example .env   # ثم ضع GEMINI_API_KEY
uvicorn server:app --host 0.0.0.0 --port 8000
```

افتح http://localhost:8000
