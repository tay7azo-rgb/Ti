"""قراءة الإعدادات من متغيرات البيئة / ملف .env — المزوّد: Google Gemini."""
import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env")


class ConfigError(Exception):
    pass


# Google Gemini عبر واجهة متوافقة مع OpenAI
GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta/openai/"
GEMINI_DEFAULT_MODEL = "gemini-2.0-flash"


@dataclass(frozen=True)
class Settings:
    api_key: str
    base_url: str
    model: str
    temperature: float
    max_tokens: int
    timeout: float
    max_history: int
    default_mode: str
    provider_name: str


def load_settings() -> Settings:
    """
    يقرأ GEMINI_API_KEY من البيئة (Render Environment أو ملف .env محليًا).
    لا يُوضع المفتاح داخل الكود أبدًا.
    """
    api_key = os.getenv("GEMINI_API_KEY", "").strip()
    if not api_key:
        raise ConfigError(
            "ما لقيت GEMINI_API_KEY. أضفه في متغيرات البيئة على Render "
            "أو في ملف .env محليًا (من Google AI Studio)."
        )

    try:
        return Settings(
            api_key=api_key,
            base_url=os.getenv("THIQ_BASE_URL", GEMINI_BASE_URL).strip(),
            model=os.getenv("THIQ_MODEL", GEMINI_DEFAULT_MODEL).strip(),
            temperature=float(os.getenv("THIQ_TEMPERATURE", "0.5")),
            max_tokens=int(os.getenv("THIQ_MAX_TOKENS", "1024")),
            timeout=float(os.getenv("THIQ_TIMEOUT", "45")),
            max_history=int(os.getenv("THIQ_MAX_HISTORY", "20")),
            default_mode=os.getenv("THIQ_DEFAULT_MODE", "general").strip(),
            provider_name="gemini",
        )
    except ValueError as e:
        raise ConfigError(f"قيمة رقمية غلط في الإعدادات: {e}")
