"""مزوّد Google Gemini عبر واجهة متوافقة مع OpenAI."""
from abc import ABC, abstractmethod

from openai import (
    APIConnectionError,
    APIStatusError,
    APITimeoutError,
    AuthenticationError,
    NotFoundError,
    OpenAI,
    PermissionDeniedError,
    RateLimitError,
)

from .config import Settings


class ThiqError(Exception):
    """خطأ مفهوم برسالة عربية واضحة للمستخدم."""


class LLMProvider(ABC):
    @abstractmethod
    def chat(self, messages: list[dict]) -> str:
        """يستقبل قائمة رسائل ويرجع نص الرد."""


class OpenAICompatibleProvider(LLMProvider):
    def __init__(self, settings: Settings):
        self.settings = settings
        self.client = OpenAI(
            api_key=settings.api_key,
            base_url=settings.base_url,
            timeout=settings.timeout,
            max_retries=2,
        )

    def chat(self, messages: list[dict]) -> str:
        s = self.settings
        try:
            response = self.client.chat.completions.create(
                model=s.model,
                messages=messages,
                temperature=s.temperature,
                max_tokens=s.max_tokens,
            )
        except AuthenticationError:
            raise ThiqError("مفتاح API غير صحيح. تأكد من GEMINI_API_KEY في متغيرات البيئة.")
        except PermissionDeniedError:
            raise ThiqError("المفتاح ما عنده صلاحية لهذا النموذج. راجع إعدادات Google AI Studio.")
        except NotFoundError:
            raise ThiqError(
                f"النموذج '{s.model}' غير موجود. جرّب THIQ_MODEL=gemini-2.0-flash"
            )
        except RateLimitError:
            raise ThiqError("وصلت حد الاستخدام. انتظر دقيقة وحاول مرة ثانية.")
        except APITimeoutError:
            raise ThiqError("انتهت مهلة الاتصال. حاول مرة ثانية.")
        except APIConnectionError:
            raise ThiqError("تعذّر الاتصال بـ Google Gemini. تأكد من الإنترنت.")
        except APIStatusError as e:
            raise ThiqError(f"خدمة Gemini رجّعت خطأ ({e.status_code}). حاول لاحقًا.")

        text = response.choices[0].message.content if response.choices else None
        if not text or not text.strip():
            raise ThiqError("وصل رد فارغ من النموذج. حاول مرة ثانية.")
        return text.strip()


def create_provider(settings: Settings) -> LLMProvider:
    return OpenAICompatibleProvider(settings)
